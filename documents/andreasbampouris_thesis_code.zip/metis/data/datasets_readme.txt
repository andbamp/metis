Iris Data Set
- iris.data.txt
- https://archive.ics.uci.edu/ml/datasets/iris

Diabetes Data
- diabetes.tab.txt
- https://www4.stat.ncsu.edu/~boos/var.select/diabetes.html

Breast Cancer Data Set
- breast-cancer.data.txt
- https://archive.ics.uci.edu/ml/datasets/Breast+Cancer

banknote authentication Data Set
- data_banknote_authentication.txt
- https://archive.ics.uci.edu/ml/datasets/banknote+authentication

Anuran Calls (MFCCs) Data Set
- Frogs_MFCCs.csv
- https://archive.ics.uci.edu/ml/datasets/Anuran+Calls+%28MFCCs%29

MNIST in CSV
- mnist_train.csv and mnist_test.csv
- https://pjreddie.com/projects/mnist-in-csv/

Wine Data Set
- wine.data.txt
- https://archive.ics.uci.edu/ml/datasets/wine